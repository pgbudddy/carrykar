from flask import Flask, request, render_template, redirect, jsonify
import requests
import uuid

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')


@app.route('/create_order', methods=['POST'])
def create_order():
    order_id = str(uuid.uuid4())
    order_amount = request.form['order_amount']
    customer_name = request.form['customer_name']
    customer_email = request.form['customer_email']
    customer_phone = request.form['customer_phone']

    print(order_amount)
    print(customer_name)
    print(customer_email)
    print(customer_phone)

    return render_template('checkout.html')


if __name__ == '__main__':
    app.run(debug=True)
