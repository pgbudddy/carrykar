from flask import Flask, render_template, jsonify, request
from cashfree_pg.models.create_order_request import CreateOrderRequest
from cashfree_pg.api_client import Cashfree
from cashfree_pg.models.customer_details import CustomerDetails
from cashfree_pg.models.order_meta import OrderMeta
from cashfree_pg.models import (  # ✅ Import missing models
    PaymentMethodAppInPaymentsEntity,
    PaymentMethodUPIInPaymentsEntity,
    PaymentMethodNetBankingInPaymentsEntity,
    PaymentMethodCardInPaymentsEntity
)
import uuid
import urllib3

# Disable SSL warnings (for testing only, not recommended for production)
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

app = Flask(__name__)

# Cashfree API Credentials
Cashfree.XClientId = "TEST103737875a3f17f9eaa86c645e9f78737301"
Cashfree.XClientSecret = "cfsk_ma_test_ee15fbbd31e3fd7ad4b3c29527d46640_175b114c"
Cashfree.XEnvironment = Cashfree.SANDBOX
x_api_version = "2023-08-01"

@app.route('/')
def home():
    return render_template('checkout.html')

@app.route('/get_payment_session', methods=['POST'])
def get_payment_session():
    data = request.get_json()
    
    customer_id = data.get("customer_id")
    customer_phone = data.get("customer_phone")
    customer_email = data.get("customer_email")
    amount = data.get("amount")

    if not customer_id or not customer_phone or not customer_email or not amount:
        return jsonify({"error": "Missing customer details or amount"}), 400

    order_id = str(uuid.uuid4())  # Generate a unique order ID
    
    customerDetails = CustomerDetails(
        customer_id=customer_id,
        customer_phone=customer_phone,
        customer_email=customer_email
    )
    
    createOrderRequest = CreateOrderRequest(
        order_id=order_id,
        order_amount=float(amount),  # Convert amount to float
        order_currency="INR",
        customer_details=customerDetails
    )
    
    orderMeta = OrderMeta()
    orderMeta.return_url = f"http://127.0.0.1:5000/check_status?order_id={order_id}"
    createOrderRequest.order_meta = orderMeta
    
    try:
        api_response = Cashfree().PGCreateOrder(x_api_version, createOrderRequest, None, None)
        print("Cashfree Response:", api_response.data)  # Debugging log
        
        if hasattr(api_response.data, "code") and api_response.data.code == "order_already_exists":
            return jsonify({"error": "Order already exists, please try again with a new order ID"}), 409
        
        if hasattr(api_response.data, "payment_session_id"):
            return jsonify({"paymentSessionId": api_response.data.payment_session_id})
        else:
            return jsonify({"error": "Invalid response from Cashfree"}), 400
    except Exception as e:
        print(f"Error: {str(e)}")
        return jsonify({"error": str(e)}), 400
    

@app.route('/check_status', methods=['GET'])
def check_status():
    order_id = request.args.get("order_id")  # Get order_id from URL
    
    if not order_id:
        return jsonify({"error": "Missing order_id in request"}), 400
    
    try:
        api_response = Cashfree().PGOrderFetchPayments(x_api_version, order_id, None)
        
        if not api_response.data:
            return jsonify({"error": "No payment data found for this order"}), 404
        
        # Extract payment details
        payment = api_response.data[0]  # Assuming only one payment entity
        
        payment_details = {
            "cf_payment_id": payment.cf_payment_id,
            "order_id": payment.order_id,
            "order_amount": payment.order_amount,
            "payment_currency": payment.payment_currency,
            "payment_amount": payment.payment_amount,
            "payment_time": payment.payment_time,
            "payment_completion_time": payment.payment_completion_time,
            "payment_status": payment.payment_status,
            "payment_message": payment.payment_message,
            "bank_reference": payment.bank_reference,
            "payment_group": payment.payment_group,
            "payment_method": {}
        }
        
        # Detect and extract payment method details
        if isinstance(payment.payment_method.actual_instance, PaymentMethodAppInPaymentsEntity):
            payment_details["payment_method"] = {
                "type": "Wallet/App",
                "provider": payment.payment_method.actual_instance.app.provider,
                "channel": payment.payment_method.actual_instance.app.channel,
                "phone": payment.payment_method.actual_instance.app.phone,
            }
        elif isinstance(payment.payment_method.actual_instance, PaymentMethodUPIInPaymentsEntity):
            payment_details["payment_method"] = {
                "type": "UPI",
                "upi_id": getattr(payment.payment_method.actual_instance.upi, "upi_id", "Unknown"),  # Adjust as per debug output
                "upi_provider": getattr(payment.payment_method.actual_instance.upi, "provider", "Unknown"),
            }
        elif isinstance(payment.payment_method.actual_instance, PaymentMethodNetBankingInPaymentsEntity):
            payment_details["payment_method"] = {
                "type": "Net Banking",
                "bank_name": getattr(payment.payment_method.actual_instance.netbanking, "bank_code", "Unknown"),  # Adjust as per debug output
            }
        elif isinstance(payment.payment_method.actual_instance, PaymentMethodCardInPaymentsEntity):
            payment_details["payment_method"] = {
                "type": "Card",
                "card_type": getattr(payment.payment_method.actual_instance.card, "card_type", "Unknown"),
                "last4": payment.payment_method.actual_instance.card.card_number if hasattr(payment.payment_method.actual_instance.card, "card_number") else "Unknown",
                "network": getattr(payment.payment_method.actual_instance.card, "card_brand", "Unknown"),  # Adjusted key name
            }
        else:
            payment_details["payment_method"] = {
                "type": "Unknown"
            }
        
        if payment_details["payment_status"] == "SUCCESS":
            print("SUCCESS")

        # Print extracted values
        print("Payment Details:", payment_details)
        
        return render_template('checkout.html')
    
    except Exception as e:
        print(f"Error: {str(e)}")
        return render_template('checkout.html')
    

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
